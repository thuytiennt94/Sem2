module.exports = {
    HOST: "localhost",
    USER: "root",
    DB: "userlist",
    PASSWORD: "",
}